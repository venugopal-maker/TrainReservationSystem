package com.trainreservation.model;

public class User {

    private int id;
    private String name;
    private String email;
    private String password;
    private String mobile;

    // NEW FIELD
    private String role;

    public User() {
    }

    public User(String name,
            String email,
            String password,
            String mobile) {

    this.name = name;
    this.email = email;
    this.password = password;
    this.mobile = mobile;
}
    
    
    
    public User(String name, String email,
            String password, String mobile,
            String role) {

        this.name = name;
        this.email = email;
        this.password = password;
        this.mobile = mobile;
        this.role = role;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    // ROLE GETTER
    public String getRole() {
        return role;
    }

    // ROLE SETTER
    public void setRole(String role) {
        this.role = role;
    }
}